package com.greatlearning.springcloud.config.client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCloudConfigclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCloudConfigclientApplication.class, args);
	}

}
