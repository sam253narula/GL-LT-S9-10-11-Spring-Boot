package com.greatlearning.springcloud.config.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCloudConfigserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCloudConfigserverApplication.class, args);
	}

}
